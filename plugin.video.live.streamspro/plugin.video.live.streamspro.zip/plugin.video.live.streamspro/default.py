
import _lspro as LS

LS.main()
